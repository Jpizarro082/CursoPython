public class App{

  //Función Principal
  public static void main(String[] args) {
    Inicio ventana = new Inicio();
    ventana.iniciarComponentes();
    ventana.setVisible(true);
  }
}
