public class PRECIOP {
    private Double precio = 0.0;

    //constructor vacio
    public PRECIOP() {
      // TODO document why this constructor is empty
    }	
	
	//getters y setters
	public Double getPRIZE() {
		return precio;
	}
	
	public void setPRIZE(Double precio) {
		this.precio = precio;
	}

}
