import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import java.awt.Color;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Inicio extends JFrame {

    public Inicio() {
        setTitle("La Tropicalita");
        setSize(1080, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    public void iniciarComponentes() {
        JPanel panel = new JPanel();
        JLabel bienvenida = new JLabel("Bienvenido a La Tropicalita, ¿Qué Desea Realizar?");
        JTextArea area = new JTextArea(1, 10);
        JButton b1 = new JButton("Comprar");// Comprar
        JButton b2 = new JButton("Abastecer");// abastecer
        JButton b3 = new JButton("Ticket");// ticket

        panel.setLayout(new FlowLayout());

        this.getContentPane().add(panel);
        // Mensaje de Bienvenida
        panel.add(bienvenida);

        // Inicialización de los parámetros básicos de la lista de productos
        String[] columnas = {"Nombre", "Precio", "Existencia", "VTI"};
        DatosPrecargados precargados = new DatosPrecargados();
        Object[][] productos = precargados.datosPrecargados();

        // Creación y Asignación de la lista
        DefaultTableModel modelo = new DefaultTableModel(productos, columnas);
        JTable tabla = new JTable(modelo);//
        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(scroll, BorderLayout.CENTER);

        // BOTONES
        area.setBorder(BorderFactory.createEtchedBorder(Color.WHITE, Color.BLACK));
        b1.setMargin(new Insets(3, 5, 3, 5));
        b2.setMargin(new Insets(3, 5, 3, 5));
        b3.setMargin(new Insets(3, 5, 3, 5));
        area.setSize(500, 500);
        // Añadir Botones
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);

        // Oyentes de los botones
        b1.addActionListener(new Oyente1());
        b2.addActionListener(new Oyente2());
        b3.addActionListener(new Oyente3());
    }

    class Oyente1 implements ActionListener{
        public void actionPerformed(ActionEvent evento){        
          Inicio comprar = new Inicio(); //Ventana de Comprar
          comprar.setVisible(true);
        }
      }
    
      class Oyente2 implements ActionListener{
        public void actionPerformed(ActionEvent evento){
          Inicio abastecer = new Inicio(); //Ventana de Abastecer
          abastecer.iniciarComponentesAbastecer(); //Iniciar componentes de abastecer
          abastecer.setVisible(true);
        }
      }
    
      class Oyente3 implements ActionListener{
        public void actionPerformed(ActionEvent evento){
          Inicio ticket = new Inicio(); //Ventana de Ticket
          ticket.setVisible(true);
        }
      }    
    public void iniciarComponentesAbastecer(){
        JPanel panelAbas = new JPanel();
        JButton btnGuardar = new JButton("Agregar");
        JTextField txtPrecio = new JTextField("", 10);
        JTextField txtCantidad = new JTextField("", 5);
        JLabel jLabelPrecio = new JLabel("Precio");
        JLabel jLabelCantidad = new JLabel("Cantidad");
        Choice selector = new Choice();

        selector.addItem("Pan Dulce");
        selector.addItem("Pan blanco");
        selector.addItem("Pan salado");
        

        panelAbas.setLayout(new FlowLayout());
        this.getContentPane().add(panelAbas);

        panelAbas.add(selector);
        panelAbas.add(jLabelPrecio);
        panelAbas.add(txtPrecio);
        panelAbas.add(jLabelCantidad);
        panelAbas.add(txtCantidad);
        panelAbas.add(btnGuardar);

        btnGuardar.addActionListener(new GuardarAbas());
    }
    class GuardarAbas implements ActionListener{
        public void actionPerformed(ActionEvent evento){
          JOptionPane.showMessageDialog(null, "Datos Guardados");
        }
      } 
}
