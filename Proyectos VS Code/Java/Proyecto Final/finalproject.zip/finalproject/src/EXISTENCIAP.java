public class EXISTENCIAP {
    private int existencia = 0;

    //constructor vacio
    public EXISTENCIAP() {
      // TODO document why this constructor is empty
    }	
	
	//getters y setters
	public Integer getEXIS() {
		return existencia;
	}
	
	public void setEXIS(Integer existencia) {
		this.existencia = existencia;
	}

}