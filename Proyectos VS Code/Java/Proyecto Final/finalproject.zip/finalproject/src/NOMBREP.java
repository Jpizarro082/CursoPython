public class NOMBREP {
    private String nombre = "";

    //constructor vacio
    public NOMBREP() {
      // TODO document why this constructor is empty
    }	
	
	//getters y setters
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


}
